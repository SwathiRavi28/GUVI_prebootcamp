const mongoose = require('mongoose');

mongoose.Promise = global.Promise;

const url = "mongodb://Swathi:1u0MiNtS5NWXrUa4@cluster0-shard-00-00.ann9b.mongodb.net:27017,cluster0-shard-00-01.ann9b.mongodb.net:27017,cluster0-shard-00-02.ann9b.mongodb.net:27017/myinvoice?ssl=true&replicaSet=atlas-11t65i-shard-0&authSource=admin&retryWrites=true&w=majority"

let mong = mongoose.connect(url, {
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology: true
}, (err) => {
    if (!err) {
        console.log('MongoDB Connection Succeeded.')
    } else {
        console.log('Error in DB connection: ' + err)
    }
});
